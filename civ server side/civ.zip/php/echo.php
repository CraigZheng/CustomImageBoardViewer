<?php
	echo "Success!";
?>